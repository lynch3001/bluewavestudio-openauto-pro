#ifndef PATHS_H
#define PATHS_H
#define DATADIR          "/usr/share"
#define SYSCONFDIR       "/etc"
#define VARRUNDIR        "/run"
#define LOCALSTATEDIR    "/var"
#define LIBDIR           "/usr/lib/arm-linux-gnueabihf"
#endif
